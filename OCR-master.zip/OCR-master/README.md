# OCR

[![How to Read Text from Image in ReactNative](http://img.youtube.com/vi/KAAS1oGddUk/0.jpg)](http://www.youtube.com/watch?v=KAAS1oGddUk "How to Read Text from Image in ReactNative")

**SUBSCRIBE**
Our Channel
**TekNik GG**

[click here](https://www.youtube.com/teknikgg?sub_confirmation=1 "click here") to SUBSCRIBE our Channel

*Share your Knowledge here...*

cmd Line:
  `npm i react-native-tesseract-ocr --save`
  `react-native link react-native-tesseract-ocr`
  
[click here](http://ethobleo.com/Jgi "click here") to download the trained Data

Don't Forget to SUBSCRIBE
Like, Comment, Share.

Support Our Channel

Follow on Instagram: https://www.instagram.com/teknikgg

Follow on Twitter: https://www.twitter.com/teknikgg

Follow on Facebook: https://www.facebook.com/teknikgg
